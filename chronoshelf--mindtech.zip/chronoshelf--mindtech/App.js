import React, { useState, useEffect, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  FlatList, 
  TextInput, 
  Alert,
  Animated,
  Easing
} from 'react-native';

// Simulated barcode database - replace with real API
const PRODUCT_DATABASE = {
  '6001067101326': { name: 'Simba Chips 150g', category: 'SNACKS' },
  '6001067101327': { name: 'Lays Chips 150g', category: 'SNACKS' },
  '6001067101328': { name: 'Coke 500ml', category: 'BEVERAGES' },
  '6001067101329': { name: 'Fanta Orange 500ml', category: 'BEVERAGES' },
  '6001067101330': { name: 'Bread White 700g', category: 'BAKERY' },
  '6001067101331': { name: 'Milk 1L', category: 'DAIRY' },
  '6001067101332': { name: 'Yoghurt 500g', category: 'DAIRY' },
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('startup');
  const [products, setProducts] = useState([]);
  const [newProduct, setNewProduct] = useState({ name: '', expiry: '', batch: '' });
  const [scannedCode, setScannedCode] = useState('');
  const [showReminder, setShowReminder] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  // Startup animation
  useEffect(() => {
    if (currentScreen === 'startup') {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 2000,
        easing: Easing.ease,
        useNativeDriver: true,
      }).start(() => {
        setTimeout(() => setCurrentScreen('main'), 2500);
      });
    }
  }, [currentScreen]);

  // Reminder system for critical stock
  useEffect(() => {
    const criticalItems = products.filter(p => p.priority === 'CRITICAL');
    if (criticalItems.length > 0) {
      const reminderInterval = setInterval(() => {
        setShowReminder(true);
        setTimeout(() => setShowReminder(false), 5000);
      }, 30000); // Remind every 30 seconds

      return () => clearInterval(reminderInterval);
    }
  }, [products]);

  // Manual barcode input simulation
  const simulateBarcodeScan = (barcode) => {
    const product = PRODUCT_DATABASE[barcode];
    if (product) {
      setNewProduct({...newProduct, name: product.name});
      Alert.alert('✅ Product Found!', `${product.name}\nCategory: ${product.category}`);
    } else {
      Alert.alert('❌ Product Not Found', 'Please enter product details manually');
    }
  };

  const addProduct = () => {
    if (newProduct.name && newProduct.expiry && newProduct.batch) {
      const priority = calculatePriority(newProduct.expiry);
      const newProductWithId = {
        ...newProduct,
        id: Date.now().toString(),
        priority,
        addedAt: new Date().toISOString()
      };
      
      setProducts([newProductWithId, ...products]);
      setNewProduct({ name: '', expiry: '', batch: '' });
      setScannedCode('');
      
      Alert.alert('✅ Success', 'Product added to inventory!');
      
      // Auto-reminder for critical items
      if (priority === 'CRITICAL') {
        setTimeout(() => {
          Alert.alert('🚨 URGENT REMINDER', `Shelve ${newProduct.name} immediately! Expires soon.`);
        }, 2000);
      }
    } else {
      Alert.alert('⚠️ Incomplete', 'Please fill all fields');
    }
  };

  const calculatePriority = (expiryDate) => {
    const today = new Date();
    const expiry = new Date(expiryDate);
    const diffDays = Math.ceil((expiry - today) / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 2) return 'CRITICAL';
    if (diffDays <= 5) return 'HIGH';
    if (diffDays <= 10) return 'MEDIUM';
    return 'LOW';
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'CRITICAL': return '#ff4757';
      case 'HIGH': return '#ffa502';
      case 'MEDIUM': return '#ffdd00';
      default: return '#2ed573';
    }
  };

  const markAsShelved = (id) => {
    setProducts(products.filter(product => product.id !== id));
    Alert.alert('✅ Complete', 'Product marked as shelved');
  };

  const calculateWasteValue = () => {
    const criticalItems = products.filter(p => p.priority === 'CRITICAL').length;
    const highItems = products.filter(p => p.priority === 'HIGH').length;
    return (criticalItems * 85) + (highItems * 45);
  };

  const getUrgentItems = () => {
    return products.filter(p => p.priority === 'CRITICAL' || p.priority === 'HIGH');
  };

  // Startup Screen
    // Startup Screen
  if (currentScreen === 'startup') {
    return (
      <View style={styles.startupContainer}>
        <Animated.View style={[styles.startupContent, { opacity: fadeAnim }]}>
          <Text style={styles.startupTitle}>MINDTECH</Text>
          <View style={styles.loadingBar}>
            <View style={styles.loadingProgress} />
          </View>
        </Animated.View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* TECH HEADER */}
      <View style={styles.header}>
        <Text style={styles.title}>CHRONOSHELF</Text>
        <Text style={styles.subtitle}>AI-Powered Inventory System</Text>
        <Text style={styles.techBadge}>v2.0 • MIND TECH</Text>
      </View>

      {/* URGENT REMINDER BANNER */}
      {showReminder && (
        <View style={styles.reminderBanner}>
          <Text style={styles.reminderText}>🚨 URGENT: {getUrgentItems().length} items need shelving!</Text>
        </View>
      )}

      {/* ANALYTICS DASHBOARD */}
      <View style={styles.dashboard}>
        <View style={styles.metricCard}>
          <Text style={styles.metricValue}>{products.length}</Text>
          <Text style={styles.metricLabel}>Total Items</Text>
        </View>
        <View style={styles.metricCard}>
          <Text style={styles.metricValue}>{getUrgentItems().length}</Text>
          <Text style={styles.metricLabel}>Urgent</Text>
        </View>
        <View style={styles.metricCard}>
          <Text style={styles.metricValue}>R{calculateWasteValue()}</Text>
          <Text style={styles.metricLabel}>Risk Value</Text>
        </View>
      </View>

      {/* SCANNER SIMULATION */}
      <View style={styles.scannerSection}>
        <Text style={styles.sectionTitle}>QUICK SCAN INPUT</Text>
        <View style={styles.scannerInputRow}>
          <TextInput
            style={styles.scannerInput}
            placeholder="Enter barcode manually"
            placeholderTextColor="#888"
            value={scannedCode}
            onChangeText={setScannedCode}
            keyboardType="number-pad"
          />
          <TouchableOpacity 
            style={styles.scanButton}
            onPress={() => scannedCode && simulateBarcodeScan(scannedCode)}
          >
            <Text style={styles.scanButtonText}>SCAN</Text>
          </TouchableOpacity>
        </View>
        
        {/* QUICK BARCODE BUTTONS */}
        <View style={styles.quickScanRow}>
          <Text style={styles.quickScanLabel}>Test Barcodes:</Text>
          {Object.keys(PRODUCT_DATABASE).slice(0, 3).map(barcode => (
            <TouchableOpacity 
              key={barcode}
              style={styles.quickScanButton}
              onPress={() => simulateBarcodeScan(barcode)}
            >
              <Text style={styles.quickScanText}>{barcode.slice(-4)}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* ADD PRODUCT FORM */}
      <View style={styles.form}>
        <Text style={styles.formTitle}>ADD PRODUCT</Text>
        <TextInput
          style={styles.input}
          placeholder="Product Name"
          placeholderTextColor="#888"
          value={newProduct.name}
          onChangeText={(text) => setNewProduct({...newProduct, name: text})}
        />
        <TextInput
          style={styles.input}
          placeholder="Expiry Date (YYYY-MM-DD)"
          placeholderTextColor="#888"
          value={newProduct.expiry}
          onChangeText={(text) => setNewProduct({...newProduct, expiry: text})}
        />
        <TextInput
          style={styles.input}
          placeholder="Batch Number"
          placeholderTextColor="#888"
          value={newProduct.batch}
          onChangeText={(text) => setNewProduct({...newProduct, batch: text})}
        />
        <TouchableOpacity style={styles.addButton} onPress={addProduct}>
          <Text style={styles.addButtonText}>ADD TO INVENTORY</Text>
        </TouchableOpacity>
      </View>

      {/* PRIORITY STACK */}
      <View style={styles.prioritySection}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>PRIORITY STACK</Text>
          <Text style={styles.sectionSubtitle}>Most urgent first</Text>
        </View>
        
        {products.length === 0 ? (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>No products added yet</Text>
            <Text style={styles.emptyStateSubtext}>Scan or add products to begin</Text>
          </View>
        ) : (
          <FlatList
            data={products.sort((a, b) => {
              const priorityOrder = { CRITICAL: 1, HIGH: 2, MEDIUM: 3, LOW: 4 };
              return priorityOrder[a.priority] - priorityOrder[b.priority];
            })}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={[styles.productItem, { borderLeftColor: getPriorityColor(item.priority) }]}>
                <View style={styles.productInfo}>
                  <Text style={styles.productName}>{item.name}</Text>
                  <View style={styles.productMeta}>
                    <Text style={styles.productBatch}>#{item.batch}</Text>
                    <Text style={styles.productExpiry}>📅 {item.expiry}</Text>
                  </View>
                  {item.priority === 'CRITICAL' && (
                    <Text style={styles.urgentBadge}>🚨 SHELVE IMMEDIATELY</Text>
                  )}
                </View>
                <View style={styles.productActions}>
                  <Text style={[styles.priorityBadge, { backgroundColor: getPriorityColor(item.priority) }]}>
                    {item.priority}
                  </Text>
                  <TouchableOpacity 
                    style={styles.shelveButton}
                    onPress={() => markAsShelved(item.id)}
                  >
                    <Text style={styles.shelveButtonText}>SHELVED</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // Startup Screen Styles
  startupContainer: {
    flex: 1,
    backgroundColor: '#0a1a2f',
    justifyContent: 'center',
    alignItems: 'center',
  },
  startupContent: {
    alignItems: 'center',
  },
  startupLogo: {
    fontSize: 80,
    marginBottom: 20,
  },
  startupTitle: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#00d4ff',
    marginBottom: 10,
    textShadowColor: '#00d4ff',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  startupSubtitle: {
    fontSize: 18,
    color: '#8899aa',
    marginBottom: 5,
    fontWeight: '600',
  },
  startupTagline: {
    fontSize: 14,
    color: '#556677',
    marginBottom: 40,
  },
  loadingBar: {
    width: 200,
    height: 4,
    backgroundColor: '#112233',
    borderRadius: 2,
    overflow: 'hidden',
  },
  loadingProgress: {
    height: '100%',
    backgroundColor: '#00d4ff',
    width: '30%',
    borderRadius: 2,
  },

  // Main App Styles
  container: {
    flex: 1,
    backgroundColor: '#0f1b2d',
    padding: 16,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
    paddingTop: 50,
    borderBottomWidth: 1,
    borderBottomColor: '#1e2b3d',
    paddingBottom: 15,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#00d4ff',
    textShadowColor: '#00d4ff',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#8899aa',
    marginTop: 4,
    fontWeight: '600',
  },
  techBadge: {
    fontSize: 12,
    color: '#556677',
    marginTop: 6,
    fontWeight: '500',
  },
  reminderBanner: {
    backgroundColor: '#ff4757',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
  },
  reminderText: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 14,
  },
  dashboard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  metricCard: {
    backgroundColor: '#1e2b3d',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#00d4ff',
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 12,
    color: '#8899aa',
  },
  scannerSection: {
    backgroundColor: '#1e2b3d',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
  },
  sectionTitle: {
    color: '#00d4ff',
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 10,
  },
  scannerInputRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  scannerInput: {
    flex: 1,
    backgroundColor: '#2a3b52',
    padding: 12,
    borderRadius: 6,
    color: 'white',
    marginRight: 10,
    borderWidth: 1,
    borderColor: '#334455',
  },
  scanButton: {
    backgroundColor: '#00d4ff',
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 6,
    justifyContent: 'center',
  },
  scanButtonText: {
    color: '#0a1a2f',
    fontWeight: 'bold',
  },
  quickScanRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  quickScanLabel: {
    color: '#8899aa',
    fontSize: 12,
    marginRight: 10,
  },
  quickScanButton: {
    backgroundColor: '#2a3b52',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    marginRight: 8,
  },
  quickScanText: {
    color: '#00d4ff',
    fontSize: 10,
    fontWeight: 'bold',
  },
  form: {
    backgroundColor: '#1e2b3d',
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
  },
  formTitle: {
    color: '#00d4ff',
    fontWeight: 'bold',
    marginBottom: 12,
    fontSize: 16,
  },
  input: {
    backgroundColor: '#2a3b52',
    padding: 14,
    borderRadius: 6,
    marginBottom: 12,
    color: 'white',
    borderWidth: 1,
    borderColor: '#334455',
    fontSize: 16,
  },
  addButton: {
    backgroundColor: '#00d4ff',
    padding: 16,
    borderRadius: 6,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#0a1a2f',
    fontWeight: 'bold',
    fontSize: 16,
  },
  prioritySection: {
    flex: 1,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionSubtitle: {
    color: '#8899aa',
    fontSize: 12,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyStateText: {
    color: '#8899aa',
    fontSize: 16,
    marginBottom: 8,
  },
  emptyStateSubtext: {
    color: '#556677',
    fontSize: 12,
  },
  productItem: {
    backgroundColor: '#1e2b3d',
    padding: 15,
    borderRadius: 6,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderLeftWidth: 4,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
    marginBottom: 8,
  },
  productMeta: {
    flexDirection: 'row',
    marginBottom: 6,
  },
  productBatch: {
    color: '#8899aa',
    fontSize: 12,
    marginRight: 15,
  },
  productExpiry: {
    color: '#ffa502',
    fontSize: 12,
    fontWeight: 'bold',
  },
  urgentBadge: {
    color: '#ff4757',
    fontSize: 10,
    fontWeight: 'bold',
    marginTop: 4,
  },
  productActions: {
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  priorityBadge: {
    color: 'white',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 4,
    fontSize: 10,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  shelveButton: {
    backgroundColor: '#00d4ff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
  },
  shelveButtonText: {
    color: '#0a1a2f',
    fontSize: 10,
    fontWeight: 'bold',
  },
});